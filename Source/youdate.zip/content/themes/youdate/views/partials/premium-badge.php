<?php

/** @var $model \app\models\User */

?>
<div class="user-premium-badge d-flex align-items-center justify-content-center" rel="tooltip"
     title="<?= Yii::t('youdate', 'Premium user') ?>">
    <i class="fe fe-star"></i>
</div>
