<div class="important-messages">
    <?= $this->render('//partials/user-confirmation') ?>
    <?= \youdate\widgets\ImportantNewsWidget::widget() ?>
</div>
