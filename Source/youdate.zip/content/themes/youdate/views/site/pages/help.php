<?php

/**
 * try also: page-single,  page-wide
 */
$this->context->layout = 'page-main';
$this->title = 'Help';
?>
<div class="card">
    <div class="card-body">
        <div class="text-wrap p-lg-6">
            <h2 class="mt-0 mb-4">Help</h2>
            <div class="alert alert-warning">
                <strong>Warning:</strong> You have to change this page by editing this file - <code>content/pages/help.php</code>
                (source file <code>content/themes/youdate/views/site/pages/help.php</code>)
            </div>
            <p>Lorem ipsum dolor sit amet, ex vis oportere deterruisset consequuntur, an vel ipsum mundi nostrum, tempor accumsan conceptam et est. Alii dico deleniti est cu, no sea nostrud accommodare. Solum quaestio no per, est ex accumsan partiendo. Cu vide etiam cetero ius. Mei facilisis consequuntur an. Ei vero ancillae his.</p>
            <p>Sea tale sadipscing eu. Virtute discere detraxit in mei, enim elitr te vis. Et quod illum elaboraret has. Ad quas petentium conclusionemque vel, vero ponderum has ex.</p>
        </div>
    </div>
</div>
