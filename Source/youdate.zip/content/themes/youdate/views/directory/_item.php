<?php

/** @var $model \app\models\User */

?>
<div class="col-6 col-sm-6 col-md-4 col-lg-3 directory-item">
    <?= $this->render('_item_body', ['model' => $model]) ?>
</div>
