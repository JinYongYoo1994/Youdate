<?php

/** @var $model \app\models\Group */

?>
<div class="col-12 col-sm-12 col-md-6 group-item">
    <?= $this->render('_item-body', ['model' => $model]) ?>
</div>
