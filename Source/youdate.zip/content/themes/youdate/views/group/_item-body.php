<?php

use app\helpers\Url;
use app\helpers\Html;

/** @var $model \app\models\Group */

$groupUrl = Url::to(['/group/view', 'alias' => $model->alias]);
$subString = isset($subString) ? $subString : $model->getDisplayLocation();
?>
<div class="card card-aside" data-group-id="<?= $model->id ?>">
    <?php if (isset($model->photo)): ?>
        <a href="<?= $groupUrl ?>"
           title="<?= Html::encode($model->getDisplayTitle()) ?>"
           class="card-aside-column" style="background-image: url(<?= $model->getPhotoThumbnail(400, 400) ?>)"></a>
    <?php else: ?>
        <a href="<?= $groupUrl ?>" class="card-aside-column no-photo d-flex justify-content-center align-items-center">
            <i class="fe fe-image"></i>
        </a>
    <?php endif; ?>
    <?php if ($model->is_verified): ?>
        <div class="group-verified-badge" rel="tooltip"
             title="<?= Yii::t('youdate', 'Verified group') ?>">
            <i class="fe fe-check"></i>
        </div>
    <?php endif; ?>
    <div class="card-body d-flex flex-column">
        <h4><a href="<?= $groupUrl ?>"><?= Html::encode($model->getDisplayTitle()) ?></a></h4>
        <div class="text-muted max-lines-3"><?= Html::encode($model->getShortDescription()) ?></div>
        <div class="d-flex align-items-center pt-5 mt-auto">
            <div class="badge badge-secondary">
                <?= $model->getGroupUsersCount() ?> <i class="fe fe-users ml-1"></i>
            </div>
        </div>
    </div>
</div>
