<div class="card">
    <div class="card-body">
        <?= \youdate\widgets\EmptyState::widget([
            'icon' => 'fe fe-edit',
            'title' => Yii::t('youdate', 'No posts yet'),
            'subTitle' => Yii::t('youdate', 'Be the first and write something'),
        ]) ?>
    </div>
</div>
