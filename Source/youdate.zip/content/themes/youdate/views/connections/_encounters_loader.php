<div class="row align-self-center h-100 w-100" ng-show="!initialStateLoaded" style="min-height: 200px;">
    <div class="dimmer active w-100 d-flex justify-content-center align-items-center">
        <div class="loader"></div>
        <div class="dimmer-content mt-9">
            <?= Yii::t('youdate', 'Loading encounters...') ?>
        </div>
    </div>
</div>
