<?php

/** @var $model \app\models\User */

?>
<div class="col-6 col-sm-6 col-md-4 directory-item">
    <?= $this->render('/directory/_item_body', ['model' => $model]) ?>
</div>
