<?php

/** @var \app\models\User $user */
/** @var \app\base\View $this */
/** @var string $downloadUrl */

?>

<?= Yii::t('youdate', 'Your profile data archive is available for download') ?>:

<?= $downloadUrl ?>
