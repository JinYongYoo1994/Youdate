<div class="text-muted pt-2 pb-2">
    <?= Yii::t('youdate', 'You have no transactions yet') ?>
</div>
