<div class="row align-self-center h-100 w-100" ng-show="!initialStateLoaded" style="min-height: 200px;">
    <div class="dimmer active w-100 m-auto text-center">
        <div class="loader"></div>
        <div class="dimmer-content">
            <?= Yii::t('youdate', 'Loading messages...') ?>
        </div>
    </div>
</div>
