<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <div class="slides"></div>
    <h3 class="title"></h3>
    <a class="prev text-light">‹</a>
    <a class="next text-light">›</a>
    <a class="close text-light"></a>
    <a class="play-pause"></a>
    <ol class="indicator"></ol>
</div>
