<div class="col-6 col-sm-4 col-md-3 col-lg-3 directory-item">
    <?= $this->render('//directory/_item_body', ['model' => $model]) ?>
</div>
