<?php

use youdate\widgets\ActiveForm;
use app\helpers\Html;

/** @var $postForm \app\forms\PostForm */
/** @var $route string */

?>
<?php $form = ActiveForm::begin([
    'id' => 'post-form',
    'enableClientValidation' => true,
    'action' => $route,
]); ?>
<div class="card post-new">
    <div class="card-body">
        <?= $form->field($postForm, 'content')
            ->textarea([
                'class' => 'form-control post-content-field',
                'rows' => 1,
                'placeholder' => Yii::t('youdate', 'New post'),
            ])
            ->label(false) ?>
    </div>
    <div class="card-footer">
        <?= Html::submitButton(Yii::t('youdate', 'Post'), ['class' => 'btn float-right btn-primary']) ?>
    </div>
</div>
<?php ActiveForm::end(); ?>
