<?php

use app\helpers\Url;
use app\helpers\Html;
use Carbon\Carbon;

/** @var $post \app\models\Post */
/** @var $canDelete bool */
/** @var $reportUrl string */
/** @var $deleteUrl string */

$user = $post->user;
$userProfile = $user->profile;
?>
<div class="post card" data-post-id="<?= $post->id ?>">
    <div class="post-body card-body">
        <div class="media">
            <a href="<?= Url::to(['profile/view', 'username' => $user->username]) ?>"
               data-pjax="0"
                class="media-object avatar avatar-md mr-4" style="background-image: url(<?= $userProfile->getAvatarUrl() ?>)"></a>
            <div class="media-body">
                <div class="media-heading mb-2 d-flex justify-content-between">
                    <a href="<?= Url::to(['profile/view', 'username' => $user->username]) ?>" data-pjax="0">
                        <h5 class="mb-1"><?= Html::encode($userProfile->getDisplayName()) ?></h5>
                    </a>
                    <div class="text-right text-muted" rel="tooltip" title="<?= Yii::$app->formatter->asDatetime($post->created_at) ?>">
                        <?= Carbon::createFromTimestampUTC($post->created_at)
                            ->locale(Yii::$app->language)
                            ->diffForHumans() ?>
                    </div>
                </div>
                <div>
                    <?= nl2br(Html::encode(trim($post->content))) ?>
                </div>
            </div>
        </div>
    </div>
    <div class="post-footer card-footer d-flex">
        <?= \hauntd\vote\widgets\Like::widget([
            'entity' => 'postLike',
            'model' => $post,
            'buttonOptions' => [
                'class' => 'vote-btn btn btn-icon btn-like',
                'icon' => Html::tag('i', '', ['class' => 'fa fa-heart']),
                'label' => false,
            ]
        ]); ?>
        <?php if ($canDelete): ?>
            <div class="dropdown ml-auto">
                <button class="btn btn-icon btn-more dropdown-toggle"
                        type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fe fe-more-horizontal"></i>
                </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item btn-ajax"
                           data-type="post"
                           data-confirm-title="<?= Yii::t('youdate', 'Do you really want to delete this post?') ?>"
                           data-pjax="0"
                           data-pjax-container="#pjax-group-posts"
                           href="<?= $deleteUrl ?>">
                            <?= Yii::t('youdate', 'Delete post') ?>
                        </a>
                    </div>
            </div>
        <?php endif; ?>
    </div>
</div>
