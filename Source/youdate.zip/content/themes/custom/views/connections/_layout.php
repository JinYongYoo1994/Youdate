<?php

/* @var $this \app\base\View */
/* @var $dataProvider \yii\data\ActiveDataProvider */
/* @var $type string */
/* @var $counters array */
/* @var $content string */

?>
<div class="page-content w-100 min-h-100">
    <div class="row h-100">
        <div class="col-lg-12 d-flex flex-column">
            <?= $content ?>
        </div>
    </div>
</div>
