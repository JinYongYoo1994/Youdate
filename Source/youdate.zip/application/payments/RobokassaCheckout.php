<?php

namespace app\payments;

use app\helpers\Common;
use app\managers\BalanceManager;
use Yii;
use yii\base\Exception;
use yii\web\BadRequestHttpException;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\payments
 */
class RobokassaCheckout extends Checkout
{
    /**
     * @var string
     */
    protected $merchantLogin;
    /**
     * @var string
     */
    protected $merchantPassword1;
    /**
     * @var string
     */
    protected $merchantPassword2;
    /**
     * @var boolean
     */
    protected $isTest = false;
    /**
     * @var string
     */
    protected $baseUrl = 'https://auth.robokassa.ru/Merchant/Index.aspx';
    /**
     * @var string
     */
    protected $hashAlgorithm = 'sha1';
    /**
     * @var string
     */
    protected $outSumCurrency = 'USD';

    /**
     * @param $merchantLogin
     */
    public function setMerchantLogin($merchantLogin)
    {
        $this->merchantLogin = $merchantLogin;
    }

    /**
     * @param $merchantPassword1
     */
    public function setPassword1($merchantPassword1)
    {
        $this->merchantPassword1 = $merchantPassword1;
    }

    /**
     * @param $merchantPassword2
     */
    public function setPassword2($merchantPassword2)
    {
        $this->merchantPassword2 = $merchantPassword2;
    }

    /**
     * @param $baseUrl
     */
    public function setBaseUrl($baseUrl)
    {
        $this->baseUrl = $baseUrl;
    }

    /**
     * @param $isTest
     */
    public function setIsTest($isTest)
    {
        $this->isTest = $isTest;
    }

    /**
     * @param $hashAlgorithm
     */
    public function setHashAlgorithm($hashAlgorithm)
    {
        $this->hashAlgorithm = $hashAlgorithm;
    }

    /**
     * @param $outSumCurrency
     */
    public function setOutSumCurrency($outSumCurrency)
    {
        $this->outSumCurrency = $outSumCurrency;
    }

    /**
     * @return mixed|\yii\web\Response
     * @throws Exception
     */
    public function checkout()
    {
        $shp = [
            'Shp_credits' => $this->credits,
            'Shp_userId' => $this->user->id,
        ];

        Yii::$app->session->set('robokassaCreditsPurchased', $this->credits);
        $signature = $this->generateSignature($this->getAmount(), null, $shp);

        $url = $this->baseUrl;
        $url .= '?' . http_build_query([
                'MerchantLogin' => $this->merchantLogin,
                'OutSum' => $this->getAmount(),
                'Description' => Yii::t('youdate', 'Credits replenishment'),
                'SignatureValue' => $signature,
                'Culture' => Common::getShortLanguage(Yii::$app->language),
                'Encoding' => 'utf-8',
                'OutSumCurrency' => $this->outSumCurrency,
                'Email' => $this->user->email,
                'IsTest' => $this->isTest ? 1 : null,
            ]);

        if (!empty($shp) && ($query = http_build_query($shp)) !== '') {
            $url .= '&' . $query;
        }

        return Yii::$app->response->redirect($url);
    }

    /**
     * @param $data
     * @return bool
     * @throws BadRequestHttpException
     * @throws Exception
     */
    public function validatePayment($data)
    {
        if (!isset($data['OutSum'], $data['InvId'], $data['SignatureValue'], $data['Shp_userId'], $data['Shp_credits'])) {
            throw new BadRequestHttpException();
        }

        $shp = [];
        foreach ($data as $key => $param) {
            if (strpos(strtolower($key), 'shp') === 0) {
                $shp[$key] = $param;
            }
        }

        if (!$this->checkSignature($data['SignatureValue'], $data['OutSum'], $data['InvId'], $this->merchantPassword1, $shp)) {
            throw new BadRequestHttpException('Could not validate Robokassa request');
        }

        $user = Yii::$app->userManager->getUserById($data['Shp_userId']);
        if ($user === null) {
            throw new Exception('Could not find user (Robokassa payment)');
        }

        /** @var BalanceManager $balanceManager */
        $this->credits = $data['Shp_credits'];
        $balanceManager = Yii::$app->balanceManager;
        $balanceManager->increase(['user_id' => $user->id], $this->credits, [
            'class' => RobokassaTransaction::class,
            'robokassaData' => $data,
        ]);

        Yii::$app->session->setFlash('success',
            Yii::t('app', 'Added {0} credits to your balance', $this->credits)
        );

        return true;
    }

    /**
     * @param $sSignatureValue
     * @param $nOutSum
     * @param $nInvId
     * @param $sMerchantPass
     * @param array $shp
     * @return bool
     */
    public function checkSignature($sSignatureValue, $nOutSum, $nInvId, $sMerchantPass, $shp = [])
    {
        $signature = "{$nOutSum}:{$nInvId}:{$sMerchantPass}";

        if (!empty($shp)) {
            $signature .= ':' . $this->implodeShp($shp);
        }

        return strtolower($this->encryptSignature($signature)) === strtolower($sSignatureValue);
    }

    /**
     * @param $nOutSum
     * @param $nInvId
     * @param array $shp
     * @return string
     */
    protected function generateSignature($nOutSum, $nInvId, $shp = [])
    {
        if ($nInvId === null) {
            // MerchantLogin:OutSum::OutSumCurrency:Password#1
            $signature = "{$this->merchantLogin}:{$nOutSum}::{$this->outSumCurrency}:{$this->merchantPassword1}";
        } else {
            // MerchantLogin:OutSum:InvId:OutSumCurrency:Password#1
            $signature = "{$this->merchantLogin}:{$nOutSum}:{$nInvId}:{$this->outSumCurrency}:{$this->merchantPassword1}";
        }

        if (!empty($shp)) {
            $signature .= ':' . $this->implodeShp($shp);
        }

        return strtolower($this->encryptSignature($signature));
    }

    /**
     * @param $signature
     * @return string
     */
    protected function encryptSignature($signature)
    {
        return hash($this->hashAlgorithm, $signature);
    }

    /**
     * @param $shp
     * @return string
     */
    protected function implodeShp($shp)
    {
        ksort($shp);

        foreach ($shp as $key => $value) {
            $shp[$key] = $key . '=' . $value;
        }

        return implode(':', $shp);
    }

    /**
     * @return float|integer
     * @throws Exception
     */
    protected function getAmount()
    {
        if (!$this->rate) {
            throw new Exception('Rate could not be null');
        }

        return number_format($this->credits / $this->rate, 2, '.', '');
    }
}
