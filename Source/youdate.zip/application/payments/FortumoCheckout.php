<?php

namespace app\payments;

use app\managers\BalanceManager;
use app\models\PaymentCustomer;
use app\models\User;
use Stripe\Stripe;
use Yii;
use yii\base\Exception;
use yii\web\BadRequestHttpException;
use yii\web\ForbiddenHttpException;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\payments
 */
class FortumoCheckout extends Checkout
{
    /**
     * @var string
     */
    protected $serviceId;
    /**
     * @var string
     */
    protected $secret;
    /**
     * @var array|null
     */
    protected $data;
    /**
     * @var array Fortumo IP addresses
     */
    protected $allowedIpAddresses = [
        '54.72.6.17',
        '54.72.6.23',
        '54.72.6.27',
        '54.72.6.126',
        '81.20.151.38',
        '81.20.148.122',
        '79.125.5.95',
        '79.125.5.205',
        '79.125.125.1',
    ];

    /**
     * @param $serviceId
     */
    public function setServiceId($serviceId)
    {
        $this->serviceId = $serviceId;
    }

    /**
     * @param $secret
     */
    public function setSecret($secret)
    {
        $this->secret = $secret;
    }

    /**
     * @param $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }

    /**
     * @param $addresses
     */
    public function setAllowedIpAddresses($addresses)
    {
        $this->allowedIpAddresses = $addresses;
    }

    /**
     * @return bool
     * @throws \Exception
     */
    public function validatePayment()
    {
        if (!in_array(Yii::$app->request->userIP, $this->allowedIpAddresses)) {
            throw new ForbiddenHttpException();
        }

        if (empty($this->data['sig']) || empty($this->data['service_id']) || empty($this->data['amount'])) {
            throw new BadRequestHttpException();
        }

        if ($this->serviceId !== $this->data['service_id']) {
            throw new BadRequestHttpException('Invalid service_id');
        }

        if (!$this->checkSignature($this->data, $this->secret)) {
            throw new BadRequestHttpException('Invalid signature');
        }

        if ($this->data['status'] !== 'completed') {
            return false;
        }

        $user = Yii::$app->userManager->getUserById($this->data['cuid']);
        if ($user === null) {
            throw new Exception('Could not find user (Fortumo payment)');
        }

        $this->credits = $this->data['amount'];

        /** @var BalanceManager $balanceManager */
        $balanceManager = Yii::$app->balanceManager;
        $balanceManager->increase(['user_id' => $user->id], $this->credits, [
            'class' => FortumoTransaction::class,
            'fortumoData' => $this->data,
        ]);

        Yii::$app->session->setFlash('success',
            Yii::t('app', 'Added {0} credits to your balance', $this->credits)
        );

        return true;
    }

    /**
     * @param $data
     * @param $secret
     * @return bool
     */
    public function checkSignature($data, $secret)
    {
        ksort($data);

        $str = '';
        foreach ($data as $key => $value) {
            if ($key != 'sig') {
                $str .= "$key=$value";
            }
        }

        $str .= $secret;
        $signature = md5($str);

        return $data['sig'] == $signature;
    }

    /**
     * @inheritDoc
     */
    public function checkout()
    {
        return false;
    }

    /**
     * @return float|integer
     * @throws Exception
     */
    protected function getAmount()
    {
        if (!$this->rate) {
            throw new Exception('Rate could not be null');
        }

        return $this->credits / $this->rate;
    }
}
