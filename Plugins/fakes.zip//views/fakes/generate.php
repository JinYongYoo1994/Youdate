<?php

use yii\bootstrap\Button;
use yii\bootstrap\ActiveForm;
use app\modules\admin\widgets\CountrySelector;
use app\modules\admin\widgets\CitySelector;

/* @var $this \yii\web\View */
/* @var $fakesConfig \plugins\fakes\forms\FakesConfig */
/* @var $countries array */

$this->title = Yii::t('app', 'Fakes generator');
$this->params['breadcrumbs'][] = $this->title;
$this->beginContent('@app/modules/admin/views/layouts/main.php');
?>

<?php $form = ActiveForm::begin() ?>

<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Yii::t('app', 'General') ?></h3>
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-sm-3">
                <?= $form->field($fakesConfig, 'amount')->textInput(['type' => 'number']) ?>
            </div>
            <div class="col-sm-3">
                <?= $form->field($fakesConfig, 'locale')->dropDownList($fakesConfig->getLocaleOptions(), ['prompt' => Yii::t('app', 'Default (en_US)')]) ?>
            </div>
        </div>
    </div>
</div>


<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Yii::t('app', 'Account') ?></h3>
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-sm-3">
                <?= $form->field($fakesConfig, 'verified')->dropDownList($fakesConfig->getVerifiedOptions()) ?>
            </div>
            <div class="col-sm-3">
                <?= $form->field($fakesConfig, 'password')
                    ->textInput()
                    ->hint(Yii::t('app', 'Default is {0}', 'fakefake'))
                ?>
            </div>
        </div>
    </div>
</div>

<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title"><?= Yii::t('app', 'Profile') ?></h3>
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-2">
                <?= $form->field($fakesConfig, 'sex')->dropDownList($fakesConfig->getSexOptions(), ['prompt' => Yii::t('app', 'Random')]) ?>
            </div>
            <div class="col-xs-6  col-sm-4 col-md-2">
                <?= $form->field($fakesConfig, 'fromAge')->textInput(['type' => 'number']) ?>
            </div>
            <div class="col-xs-6  col-sm-4 col-md-2">
                <?= $form->field($fakesConfig, 'toAge')->textInput(['type' => 'number']) ?>
            </div>
            <div class="col-sm-6 col-md-3">
                <?= $form
                    ->field($fakesConfig, 'country', ['inputOptions' => ['autocomplete' => 'off']])
                    ->widget(CountrySelector::class, [
                        'items' => array_merge([null => Yii::t('youdate', 'Country')], $countries),
                        'options' => ['class' => 'form-control'],
                    ]) ?>
            </div>
            <div class="col-sm-6 col-md-3">
                <?= $form
                    ->field($fakesConfig, 'city', ['inputOptions' => ['autocomplete' => 'off']])
                    ->widget(CitySelector::class) ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <?= $form->field($fakesConfig, 'photosArchive')
                    ->fileInput()
                    ->hint(Yii::t('app', 'ZIP archive with jpg/jpeg files')) ?>
            </div>
        </div>
    </div>
</div>

<div class="box box-solid">
    <div class="box-body">
        <?= Button::widget([
            'label' => Yii::t('app', 'Generate'),
            'options' => ['class' => 'btn-primary']
        ]) ?>
    </div>
</div>

<?php $form->end() ?>
